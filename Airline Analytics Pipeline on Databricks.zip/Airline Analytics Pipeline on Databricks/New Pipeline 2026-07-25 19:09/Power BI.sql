-- Databricks notebook source
-- Dashboard Query: Airport Distribution Map
SELECT 
    airport_code,
    airport_name,
    CITY AS city,
    STATE AS state,
    latitude,
    longitude,
    'Airport' AS location_type
FROM bronze.gold_dim_airports;

-- Dashboard Query: State Summary
SELECT 
    STATE AS state,
    COUNT(*) AS total_airports,
    COUNT(DISTINCT CITY) AS total_cities,
    CONCAT_WS(', ', COLLECT_LIST(DISTINCT CITY)) AS cities_list
FROM bronze.gold_dim_airports
GROUP BY STATE
ORDER BY total_airports DESC;