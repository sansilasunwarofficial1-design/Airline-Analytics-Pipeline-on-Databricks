-- Databricks notebook source
-- 03_Gold_Analytics
-- DLT Notebook for Gold Layer Processing

-- ==========================================
-- STEP 1: CREATE GOLD TABLES USING DLT
-- ==========================================

-- Gold Table 1: Airport Fact Table
CREATE OR REFRESH LIVE TABLE gold_airport_fact
COMMENT "Clean airport fact table with location data"
TBLPROPERTIES ("quality" = "gold")
AS
SELECT 
    airport_code,
    airport_name,
    city,
    state,
    country,
    latitude,
    longitude,
    CURRENT_DATE() AS fact_date
FROM live.silver_airports
WHERE latitude != 0.0 AND longitude != 0.0;

-- Gold Table 2: State Airport Summary (Aggregated)
CREATE OR REFRESH LIVE TABLE gold_state_summary
COMMENT "State-level airport aggregation"
TBLPROPERTIES ("quality" = "gold")
AS
SELECT 
    state,
    COUNT(*) AS total_airports,
    COUNT(DISTINCT city) AS total_cities,
    COLLECT_SET(city) AS cities_list
FROM live.silver_airports
GROUP BY state
ORDER BY total_airports DESC;

-- Gold Table 3: Airport-Airline Dimension (Star Schema)
CREATE OR REFRESH LIVE TABLE gold_airport_airlines_dim
COMMENT "Dimension table for airport-airline combinations"
TBLPROPERTIES ("quality" = "gold")
AS
SELECT 
    a.airport_code,
    a.airport_name,
    a.city,
    a.state,
    al.airline_code,
    al.airline_name,
    CURRENT_TIMESTAMP() AS processed_date
FROM live.silver_airports a
CROSS JOIN live.silver_airlines al;

-- ==========================================
-- STEP 2: CREATE DLT VIEWS
-- ==========================================

-- View 1: Top 10 Cities by Airport Count
CREATE OR REFRESH LIVE VIEW gold_vw_top_cities
COMMENT "Top 10 cities with most airports"
AS
SELECT 
    city,
    state,
    COUNT(*) AS airport_count,
    COLLECT_LIST(airport_name) AS airport_list
FROM live.silver_airports
GROUP BY city, state
ORDER BY airport_count DESC
LIMIT 10;

-- View 2: State Distribution
CREATE OR REFRESH LIVE VIEW gold_vw_state_distribution
COMMENT "State-wise airport distribution"
AS
SELECT 
    state,
    COUNT(*) AS airport_count,
    COUNT(DISTINCT city) AS unique_cities
FROM live.silver_airports
GROUP BY state
ORDER BY airport_count DESC;

-- View 3: Airline Summary
CREATE OR REFRESH LIVE VIEW gold_vw_airline_summary
COMMENT "Active airlines summary"
AS
SELECT 
    airline_code,
    airline_name,
    'Active' AS status,
    CURRENT_DATE() AS report_date
FROM live.silver_airlines
ORDER BY airline_name;

-- ==========================================
-- STEP 3: CREATE EXPECTATIONS (DATA QUALITY)
-- ==========================================

-- Add data quality expectations to Gold tables
-- This will be applied when DLT refreshes

ALTER TABLE gold_airport_fact
SET TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.autoOptimize.optimizeWrite' = 'true',
  'delta.autoOptimize.autoCompact' = 'true'
);

-- ==========================================
-- STEP 4: DLT PIPELINE QUALITY CHECKS
-- ==========================================

-- You can also add expectations in the pipeline configuration
-- Or create a separate validation view

CREATE OR REFRESH LIVE VIEW gold_validation_report
COMMENT "Data validation metrics for Gold layer"
AS
SELECT 
    'gold_airport_fact' AS table_name,
    COUNT(*) AS row_count,
    CURRENT_TIMESTAMP() AS validation_timestamp
FROM live.gold_airport_fact
UNION ALL
SELECT 
    'gold_state_summary',
    COUNT(*),
    CURRENT_TIMESTAMP()
FROM live.gold_state_summary
UNION ALL
SELECT 
    'gold_airport_airlines_dim',
    COUNT(*),
    CURRENT_TIMESTAMP()
FROM live.gold_airport_airlines_dim;