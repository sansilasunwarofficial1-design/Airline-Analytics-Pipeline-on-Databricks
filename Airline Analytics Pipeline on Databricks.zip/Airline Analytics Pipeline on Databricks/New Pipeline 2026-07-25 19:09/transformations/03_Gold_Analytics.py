from pyspark.sql.functions import col, concat, lit
from pyspark import pipelines as dp

# Create a Gold dimension table combining airport and location data
@dp.materialized_view(
    comment="Dimension table for airport analytics",
    table_properties={"quality": "gold"}
)
def gold_dim_airports():
    return (
        spark.read.table("silver.airports")
        .select(
            col("airport_code"),
            col("airport_name"),
            col("CITY"),
            col("STATE"),
            col("COUNTRY"),
            col("latitude"),
            col("longitude"),
            concat(col("CITY"), lit(", "), col("STATE")).alias("location"),
            col("ingestion_timestamp")
        )
    )

# Create an aggregated Gold table for airline summary
@dp.materialized_view(
    comment="Summary metrics for airlines",
    table_properties={"quality": "gold"}
)
def gold_airline_summary():
    return (
        spark.read.table("silver.airlines")
        .groupBy("airline_code", "airline_name")
        .agg(
            {"*": "count", "ingestion_timestamp": "max"}
        )
        .withColumnRenamed("count(1)", "record_count")
        .withColumnRenamed("max(ingestion_timestamp)", "last_updated")
    )